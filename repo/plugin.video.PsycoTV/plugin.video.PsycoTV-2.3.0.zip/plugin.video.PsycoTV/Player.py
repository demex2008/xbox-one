 # -*- coding: utf-8 -*- 

import base64, codecs
import xbmcaddon

MainBase = base64.b64decode('aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL1BzeWNvVFYvUHN5Y29UVi9tYXN0ZXIvcHN5Y28=')
addon = xbmcaddon.Addon('plugin.video.PsycoTV')
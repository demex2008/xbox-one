﻿#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc,xbmcgui,xbmcplugin,xbmcaddon,hsk
from contextlib import closing
from urlparse import urlparse
import sys,os,urllib,re,time
import urlresolver
#import resolveurl as urlresolver

_addon_ =  xbmcaddon.Addon()

BASE_URL = _addon_.getSetting('url_eum').strip()
POST_URL = BASE_URL + '/aGET/List/'
HOSTER_URL = BASE_URL + '/aGET/Mirror/'
EPISODES_URL = BASE_URL + '/aGET/MirrorByEpisode/'

def get_norm_url(url):
	return url.replace('\/','/').replace('&amp;','&')

def fix_encoding(path):
	if sys.platform.startswith('win'):return unicode(path,'utf-8')
	else:return unicode(path,'utf-8').encode('iso-8859-1')

player_ = xbmc.Player()
addon_ =  xbmcaddon.Addon()
addon_path_ = fix_encoding(addon_.getAddonInfo('path'))

def get_color_text(color,text):
	return '[COLOR '+color+']'+text+'[/COLOR]'

def get_search_keyboard():
	return urllib.quote(xbmcgui.Dialog().input(get_color_text('lime','Search ?'), type=xbmcgui.INPUT_ALPHANUM).strip())

def get_cf_url(url,stream=False,timeout=30,allow_redirects=False,scraper_delay=0,headers_dict={}):
	return hsk.get_cfscraper(url=url,delay=5,headers_dict=headers_dict)

def post_cf_url(url,data,stream=False,timeout=30,allow_redirects=True,scraper_delay=3,headers_dict={}):
	return hsk.post_cfscraper(url=url,data=data,delay=5,headers_dict=headers_dict)

def add_items(items_array_dict=[['','','','',{},{}]], set_items_type_int=0, set_content_type_int=0, set_params_dict=True, is_folder_bool=True, Is_playable_bool=False):

	item_type_dict ={0:'music',1:'video',2:'pictures',3:'game'}
	content_type_dict={0:'files',1:'songs',2:'artists',3:'albums',4:'movies',5:'tvshows',6:'episodes',7:'musicvideos',8:'videos',9:'images',10:'games'}

	xbmcplugin.setContent(int(sys.argv[1]),content_type_dict[set_content_type_int])

	for array_dict in items_array_dict:

		listitem=xbmcgui.ListItem(label=array_dict[0],iconImage='DefaultFolder.png',thumbnailImage=array_dict[2],path=array_dict[1])

		infolabels_dict={'Title':array_dict[0]}
		infolabels_dict.update(array_dict[4])

		params_dict={'Title':array_dict[0],'Url':array_dict[1],'Img':array_dict[2]}
		params_dict.update(array_dict[5])

		listitem.setInfo(type=item_type_dict[set_items_type_int],infoLabels=infolabels_dict)
		listitem.setProperty('fanart_image',array_dict[3])

		if(set_params_dict == True):url=sys.argv[0] +'?'+ urllib.quote_plus(str(params_dict))
		if(set_params_dict == False):url=array_dict[1]

		if(Is_playable_bool == True):listitem.setProperty('IsPlayable','true')
		if(Is_playable_bool == False):listitem.setProperty('IsPlayable','false')

		xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=listitem,isFolder=is_folder_bool,totalItems=len(items_array_dict))

	xbmcplugin.endOfDirectory(handle=int(sys.argv[1]),succeeded=True,updateListing=False,cacheToDisc=True)

def get_regex_search(regex,content):
	return re.compile(regex,re.DOTALL).search(content)

def get_regex_findall(regex,content):
	return re.compile(regex,re.DOTALL).findall(content)

def get_resolved_url(url):
	source = urlresolver.HostedMediaFile(url=url)
	if source.valid_url():return source.resolve()
	else:return ''

def get_xbmc_player(title='',url='',img=''):

	listitem = xbmcgui.ListItem(label=title,iconImage=img,thumbnailImage=img)
	listitem.setInfo(type='video',infoLabels={'Title':title})
	listitem.setProperty('IsPlayable','true')

	player_.play(item=url,listitem=listitem)
	sys.exit(0)

def get_params_dict():
	argv = urllib.unquote_plus(sys.argv[2][1:])
	if argv.startswith('{') and argv.endswith('}'):return eval(argv)
	else:return {}
get_params_ = get_params_dict()

if get_params_ == {}:

	items_array_dict=[]
	items_array_dict.append(['[COLOR lime]Kinofilme[/COLOR]',BASE_URL + '/Kino-filme.html','','',{},{'Run':'1','Request':'get'}])
	items_array_dict.append(['Alle Filme',POST_URL + 'Page=1&Per_Page=10&url=/aGET/List/&dir=desc&sort=title&per_page=10&ListMode=cover&additional={"fType":"movie","Length":60,"fLetter":""}&iDisplayStart=0&iDisplayLength=10' ,'','',{},{'Run':'1','Ref':BASE_URL + '/Film-Movies.html','Request':'post'}])
	items_array_dict.append(['Beliebte Filme',BASE_URL + '/Popular-Movies.html','','',{},{'Run':'1','Request':'get'}])
	items_array_dict.append(['Neuste Filme',BASE_URL + '/Latest-Movies.html','','',{},{'Run':'1','Request':'get'}])

	items_array_dict.append(['Alle Dokus',POST_URL + 'Page=1&Per_Page=10&url=/aGET/List/&dir=desc&sort=title&per_page=10&ListMode=cover&additional={"fType":"documentation","Length":60,"fLetter":""}&iDisplayStart=0&iDisplayLength=10' ,'','',{},{'Run':'1','Ref':BASE_URL + '/Film-Movies.html','Request':'post'}])
	items_array_dict.append(['Beliebte Dokus',BASE_URL + '/Popular-Documentations.html','','',{},{'Run':'1','Request':'get'}])
	items_array_dict.append(['Neuste Dokus',BASE_URL + '/Latest-Documentations.html','','',{},{'Run':'1','Request':'get'}])

	items_array_dict.append(['Alle Serien',POST_URL + 'Page=1&Per_Page=10&url=/aGET/List/&dir=desc&sort=title&per_page=10&ListMode=cover&additional={"fType":"series","Length":60,"fLetter":""}&iDisplayStart=0&iDisplayLength=10' ,'','',{},{'Run':'1','Ref':BASE_URL + '/Film-Movies.html','Request':'post'}])
	items_array_dict.append(['Beliebte Serien',BASE_URL + '/Popular-TVSerien.html','','',{},{'Run':'1','Request':'get'}])
	items_array_dict.append(['Neuste Serien',BASE_URL + '/Latest-TVSerien.html','','',{},{'Run':'1','Request':'get'}])
	items_array_dict.append(['[COLOR lime]Search[/COLOR]',BASE_URL + '/Search.html?q=','','',{},{'Run':'1','Request':'get','Search':'search'}])

	add_items(items_array_dict, set_items_type_int=1, set_content_type_int=0, set_params_dict=True, is_folder_bool=True, Is_playable_bool=False)

elif get_params_.get('Run') == '1':

	items_array_dict=[]
	url = get_params_.get('Url')
	ref = get_params_.get('Ref')
	req_type = get_params_.get('Request')

	if req_type == 'post':

		next_page_data = get_regex_search('\/Page=(\d+)&[\s\S]*?fType":"(.*?)"',url)

		data_dict={}
		for key,value in get_regex_findall('(\w+)\=(.+?)(?:&|$)',url):
			data_dict[key] = value

		content = post_cf_url(url,data=data_dict,headers_dict={'Origin':BASE_URL,'Referer':ref,'X-Requested-With':'XMLHttpRequest','Cookie':'ListMode=cover'}).content

		for title,url,img in get_regex_findall('<div class=."Opt leftOpt Headlne."><a title=."(.*?)." href=."(.*?)."[\s\S]*?src=."(.*?)."',content):
			items_array_dict.append([title.decode('unicode_escape'),BASE_URL + get_norm_url(url),BASE_URL + img,'',{},{'Run':'3'}])

		if next_page_data:

			new_page_nr = str(int(next_page_data.group(1)) + 1)
			new_page_url = 'Page=%s&Per_Page=10&url=/aGET/List/&dir=desc&sort=title&per_page=10&ListMode=cover&additional={"fType":"%s","Length":60,"fLetter":""}&iDisplayStart=0&iDisplayLength=10' % (new_page_nr,next_page_data.group(2))

			color_text = get_color_text('lime','Next >>')
			items_array_dict.append([color_text,POST_URL + new_page_url,'','',{},{'Run':'1','Request':'post'}])

	elif req_type == 'get':

		if get_params_.get('Search')=='search':
			text = get_search_keyboard()
			if text:url = url + text
			else:sys.exit(0)

		content = get_cf_url(url,stream=False,timeout=30,allow_redirects=True,scraper_delay=0,headers_dict={'Origin':BASE_URL,'Referer':url,'X-Requested-With':'XMLHttpRequest','Cookie':'ListMode=cover'}).content
		for title,url,img in get_regex_findall('<div class="Opt leftOpt Headlne"><a title="(.*?)"\shref="(.*?)"[\s\S]*?src="(.*?)"',content):
			items_array_dict.append([title,BASE_URL + get_norm_url(url),BASE_URL + img,'',{},{'Run':'3'}])

	add_items(items_array_dict, set_items_type_int=1, set_content_type_int=0, set_params_dict=True, is_folder_bool=True, Is_playable_bool=False)

elif get_params_.get('Run') == '2':

	url = get_params_.get('Url')
	content = get_cf_url(url,stream=False,timeout=30,allow_redirects=True,scraper_delay=0,headers_dict={'Origin':BASE_URL,'Referer':url,'X-Requested-With':'XMLHttpRequest','Cookie':'ListMode=cover'}).content

	items_array_dict=[]
	for title,url,img in get_regex_findall('<div class="Opt leftOpt Headlne"><a title="(.*?)"\shref="(.*?)"[\s\S]*?src="(.*?)"',content):
		items_array_dict.append([title,BASE_URL + get_norm_url(url),BASE_URL + img,'',{},{'Run':'3'}])

	add_items(items_array_dict, set_items_type_int=1, set_content_type_int=0, set_params_dict=True, is_folder_bool=True, Is_playable_bool=False)

elif get_params_.get('Run') == '3':

	ftitle = get_params_.get('Title')
	url = get_params_.get('Url')
	img = get_params_.get('Img')

	items_array_dict=[]
	content = get_cf_url(url,stream=False,timeout=30,allow_redirects=True,scraper_delay=0,headers_dict={}).content

	episodes_data = get_regex_search('<select[\s\S]*?rel="(.*?)"[\s\S][^<]*(.*?[\s\S]*)<\/select>',content)
	if episodes_data:
		for value,data,title in get_regex_findall('<option value="(\d+)" rel="(.*?)"[\s\S]*?>(.*?)<\/option>',episodes_data.group(2)):
			for data in data.split(','):
				items_array_dict.append([title + ' Folge ' + data +' | '+ ftitle, EPISODES_URL + get_norm_url(episodes_data.group(1)) + '&Season=%s&Episode=%s' % (value,data),img,'',{},{'Run':'3'}])

	else:
		for url,title in get_regex_findall('class="MirBtn.*?rel="([^"]+)"[\s\S]*?class="Named">(.*?)<\/div>',content):
			items_array_dict.append([title+ ' | ' +ftitle,HOSTER_URL + get_norm_url(url),img,'',{},{'Run':'4'}])

	add_items(items_array_dict, set_items_type_int=1, set_content_type_int=0, set_params_dict=True, is_folder_bool=True, Is_playable_bool=False)

elif get_params_.get('Run') == '4':
	title = get_params_.get('Title')
	url = get_params_.get('Url')
	img = get_params_.get('Img')

	content = get_cf_url(url,stream=False,timeout=30,allow_redirects=True,scraper_delay=0,headers_dict={}).content
	hoster_url = get_regex_search('Stream":"(?:<a href=\\\\"*|<iframe src=\\\\")(.*?)\\\\"',content)

	if hoster_url:
		hoster_url = get_norm_url(hoster_url.group(1))
		if not hoster_url.startswith('http'):hoster_url = 'http:' + hoster_url
		play_url = get_resolved_url(hoster_url)
		get_xbmc_player(title=title,url=play_url,img=img)
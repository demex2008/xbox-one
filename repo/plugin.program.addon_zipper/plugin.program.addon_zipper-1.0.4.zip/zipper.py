#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc,xbmcgui,xbmcaddon
import sys,os,time
import zipfile

addon = xbmcaddon.Addon()
addon_path = addon.getAddonInfo('path').decode('utf-8')

sys.path.append(os.path.join(addon_path,'resources','lib').decode('utf-8'))
from elementtree import ElementTree

kodi_addons_path = os.path.join(xbmc.translatePath('special://home'),'addons').decode('utf-8')

def clearOutputFolder(dir_path):
    if os.path.exists(dir_path) and os.path.isdir(dir_path):
        for pathentry in os.walk(dir_path, False):

            for dir in pathentry[1]:
                try:
                    path = os.path.join(pathentry[0], dir)
                    if os.path.islink(path):
                        os.unlink(path)
                    else:
                        os.rmdir(path)
                except Exception, e:
                    xbmcgui.Dialog().ok('Zip folder clear error !', str(e))
                    sys.exit(1)

            for file in pathentry[2]:
                try:
                    path = os.path.join(pathentry[0], file)
                    os.unlink(path)
                except Exception, e:
                    xbmcgui.Dialog().ok('Zip folder clear error !', str(e))
                    sys.exit(1)

        time.sleep(3)

def ZipDir(inputDir, outputZip):
    try:
        zipOut = zipfile.ZipFile(outputZip, 'w', compression=zipfile.ZIP_DEFLATED)
        rootLen = len(os.path.dirname(inputDir))
        def _ArchiveDirectory(parentDirectory):
            contents = os.listdir(parentDirectory)

            if not contents:
                archiveRoot = parentDirectory[rootLen:].replace('\\', '/').lstrip('/')
                zipInfo = zipfile.ZipInfo(archiveRoot+'/')
                zipOut.writestr(zipInfo, '')

            for item in contents:
                fullPath = os.path.join(parentDirectory, item)
                if os.path.isdir(fullPath) and not os.path.islink(fullPath):
                    _ArchiveDirectory(fullPath)
                else:
                    archiveRoot = fullPath[rootLen:].replace('\\', '/').lstrip('/')
                    if os.path.islink(fullPath):
                        zipInfo = zipfile.ZipInfo(archiveRoot)
                        zipOut.writestr(zipInfo, os.readlink(fullPath))
                    else:
                        zipOut.write(fullPath, archiveRoot, zipfile.ZIP_DEFLATED)

        _ArchiveDirectory(inputDir)
        zipOut.close()

    except Exception, e:
        xbmcgui.Dialog().ok('Zipper error !', str(e))
        sys.exit(1)
		
def get_addon(addons_dir,zip_output_path):
    try:
        if os.path.isdir(addons_dir):

            xml_path = os.path.join(addons_dir,'addon.xml')

            if os.path.isfile(xml_path):

                tree = ElementTree.parse(r'' + xml_path)
                root = tree.getroot()

                if root :
                    ZipDir(addons_dir,os.path.join(zip_output_path,root.attrib['id'] + '-' + root.attrib['version'] + '.zip'))
    except Exception, e:
        xbmcgui.Dialog().ok('ElementTree error !', str(e))
        sys.exit(1)
		
def get_addons(addons_dir,zip_output_path):
    try:
        if os.path.isdir(addons_dir):
            objects = os.listdir(addons_dir)
		
            for objectname in objects:
                if os.path.isdir(os.path.join(addons_dir,objectname)):

                    xml_path = os.path.join(addons_dir,objectname,'addon.xml')

                    if os.path.isfile(xml_path):

                        tree = ElementTree.parse(r'' + xml_path)
                        root = tree.getroot()

                        if root :
                            ZipDir(os.path.join(addons_dir,objectname),os.path.join(zip_output_path,root.attrib['id'] + '-' + root.attrib['version'] + '.zip'))
    except Exception, e:
        xbmcgui.Dialog().ok('ElementTree error !', str(e))
        sys.exit(1)
		
def get_kodi_addons(addons_dir,zip_output_path):
    try:
        if os.path.isdir(addons_dir):
            objects = os.listdir(addons_dir)
		
            for objectname in objects:
                if os.path.isdir(os.path.join(addons_dir,objectname)):

                    xml_path = os.path.join(addons_dir,objectname,'addon.xml')

                    if os.path.isfile(xml_path):

                        tree = ElementTree.parse(r'' + xml_path)
                        root = tree.getroot()

                        if root :
                            ZipDir(os.path.join(addons_dir,objectname),os.path.join(zip_output_path,root.attrib['id'] + '-' + root.attrib['version'] + '.zip'))
    except Exception, e:
        xbmcgui.Dialog().ok('ElementTree error !', str(e))
        sys.exit(1)

def input_path():
    input_path_browser =''
    input_path_browser = xbmcgui.Dialog().browse(3,'Eingabe Pfad ?','files', '', False, False).decode('utf-8')
    if input_path_browser == '':
        sys.exit(0)
    if not os.path.exists(input_path_browser) and not os.path.isdir(input_path_browser):
        sys.exit(0)
    return input_path_browser
		
def output_path():
    output_path_browser =''
    if str(addon.getSetting('remote_path_off_on')) == 'false':
        output_path_browser = xbmcgui.Dialog().browse(3,'Zip Ausgabe Pfad ?','files', '', False, False).decode('utf-8')
        if output_path_browser == '':
            sys.exit(0)
    else:
        output_path_browser = str(addon.getSetting('remote_path')).decode('utf-8')
    if not os.path.exists(output_path_browser) and not os.path.isdir(output_path_browser):
        sys.exit(0)
    return output_path_browser

call = xbmcgui.Dialog().select('Kodi Addon Zipper', ['[COLOR lime]Ein Addon zippen ![/COLOR]' , '[COLOR lime]Alle Addons zippen ![/COLOR]' , '[COLOR lime]Alle Kodi Addons zippen ![/COLOR]'])
if call == -1:
    sys.exit(0)
	
if call == 0:
    input_path_browser = input_path()
    output_path_browser = output_path()
    if  str(addon.getSetting('remote_path_clear')) == 'true':
        clearOutputFolder(output_path_browser)
    get_addon(os.path.abspath(input_path_browser),output_path_browser)
    xbmcgui.Dialog().ok('Fertig !', 'Das Addon wurden gezippt !')

if call == 1:
    input_path_browser = input_path()
    output_path_browser = output_path()
    if  str(addon.getSetting('remote_path_clear')) == 'true':
        clearOutputFolder(output_path_browser)
    get_addons(input_path_browser,output_path_browser)
    xbmcgui.Dialog().ok('Fertig !', 'Alle Addons wurden gezippt !')

if call == 2:
    output_path_browser = output_path()
    if  str(addon.getSetting('remote_path_clear')) == 'true':
        clearOutputFolder(output_path_browser)
    get_kodi_addons(kodi_addons_path,output_path_browser)
    xbmcgui.Dialog().ok('Fertig !', 'Alle Kodi Addons wurden gezippt !')
#Created by Andre Albus - Loki1979
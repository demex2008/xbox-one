# Python code obfuscated by www.development-tools.net 
 

import base64, codecs
magic = 'ICMgLSotIGNvZGluZzogdXRmLTggLSotIAoKaW1wb3J0IGJhc2U2NCwgY29kZWNzCmlt'
love = 'pT9lqPO4Lz1wLJExo24XPx1unJ5PLKAyVQ0tLzSmMGL0YzV2ATEyL29xMFtaLHuFZTAR'
god = 'b3ZMM0psY0c4dWMzUjFZbVV1YjNKbkwzUjJiR2x6ZEM5dVpYZGZjM1IwZGk1MGVIUT0n'
destiny = 'XDcuMTEiovN9VUuvoJAuMTEiov5OMTEiovtapTk1M2yhYaMcMTIiYyA0qJWyISLaXD=='
joy = '\x72\x6f\x74\x31\x33'
trust = eval('\x6d\x61\x67\x69\x63') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x6c\x6f\x76\x65\x2c\x20\x6a\x6f\x79\x29') + eval('\x67\x6f\x64') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x64\x65\x73\x74\x69\x6e\x79\x2c\x20\x6a\x6f\x79\x29')
eval(compile(base64.b64decode(eval('\x74\x72\x75\x73\x74')),'<string>','exec'))